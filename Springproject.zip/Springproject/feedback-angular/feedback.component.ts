import { Component, OnInit } from '@angular/core';
import { Feedback } from '../feedback';
import { FeedbackService } from '../feedback.service';

@Component({
  selector: 'app-feedback',
  templateUrl: './feedback.component.html',
  styleUrls: ['./feedback.component.css']
})
export class FeedbackComponent implements OnInit {
  feedback: Feedback=new Feedback; 
  constructor(private service:FeedbackService) { }

  ngOnInit(): void {
    this.feedback= new Feedback();
  }

  currentRating=0;
  starRating = 0;
  currentRate = 3.14;

  saveFeedback()
  {
    this.service.createFeedback(this.feedback)
    .subscribe(data=>{ 
    console.log(data)},
    error=>{console.log(error);
    });
  }

  onSubmit()
  { console.log(this.feedback);
     this.saveFeedback();}

  
}


