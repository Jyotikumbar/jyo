package feedback.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import feedback.model.Feedback;

public interface FeedbackRepository extends JpaRepository<Feedback, Integer>
{

}
