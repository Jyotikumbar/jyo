package feedback.service.impl;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import feedback.model.Feedback;
import feedback.repo.FeedbackRepository;
import feedback.service.IFeedbackService;

@Service
public class FeedbackServiceImpl implements IFeedbackService {

	@Autowired
	private FeedbackRepository repo;
	
	@Override
	public Feedback createFeedback(Feedback feedback) {
		
		return repo.save(feedback);
	}

}
