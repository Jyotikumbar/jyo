package feedback.service;

import java.util.List;
import java.util.Optional;

import feedback.model.Feedback;

public interface IFeedbackService {

	Feedback createFeedback(Feedback f);
	//void updateStudent(Feedback s);
	
	//void deleteStudent(Integer id);

	//Optional<Feedback> getOneStudent(Integer id);
	//List<Feedback> getAllStudents();

	//boolean isStudentExist(Integer id);
}
