package com.dineshonjava.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

 
@Entity
@Table(name="Employee")
public class Employee implements Serializable{

	 
	
	@Id
	 
	@Column(name = "cusid")
	private Integer cusId;
	
	@Column(name="cusname")
	private String cusName;
	
	@Column(name="cusaddress")
	private String cusAddress;
	
	@Column(name="cusphone")
	private String cusPhone;
	
	@Column(name="cusemail")
	private String cusEmail;
	
	@Column(name="cuscompany")
	private String cusCompany;
	
	@Column(name="cusbalance")
	private Integer cusBalance;
	
	@Column(name="cusage")
	private Integer cusAge;

	public Integer getCusId() {
		return cusId;
	}

	public void setCusId(Integer cusId) {
		this.cusId = cusId;
	}

	public String getCusName() {
		return cusName;
	}

	public void setCusName(String cusName) {
		this.cusName = cusName;
	}

	public String getCusAddress() {
		return cusAddress;
	}

	public void setCusAddress(String cusAddress) {
		this.cusAddress = cusAddress;
	}

	public String getCusPhone() {
		return cusPhone;
	}

	public void setCusPhone(String cusPhone) {
		this.cusPhone = cusPhone;
	}

	public String getCusEmail() {
		return cusEmail;
	}

	public void setCusEmail(String cusEmail) {
		this.cusEmail = cusEmail;
	}

	public String getCusCompany() {
		return cusCompany;
	}

	public void setCusCompany(String cusCompany) {
		this.cusCompany = cusCompany;
	}

	public Integer getCusBalance() {
		return cusBalance;
	}

	public void setCusBalance(Integer cusBalance) {
		this.cusBalance = cusBalance;
	}

	public Integer getCusAge() {
		return cusAge;
	}

	public void setCusAge(Integer cusAge) {
		this.cusAge = cusAge;
	}
	
	

	
}
