package com.dineshonjava.bean;

 //create table employee(empid number,empname varchar2(30),empage number,salary number,empaddress varchar2(30));
//create table customer(cusid number,cusname varchar2(30),cusaddress varchar2(30),cusphone varchar2(30),cusemail varchar2(30),cuscompany varchar2(30),cusage number,cusbalance number)
public class EmployeeBean {
	private Integer id;
	private String name;
	private Integer age;
	private Integer balance;
	private String address;
	private String phone;
	private String email;
	private String company;
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public Integer getAge() {
		return age;
	}
	public void setAge(Integer age) {
		this.age = age;
	}
	public Integer getBalance() {
		return balance;
	}
	public void setBalance(Integer balance) {
		this.balance = balance;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getPhone() {
		return phone;
	}
	public void setPhone(String phone) {
		this.phone = phone;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getCompany() {
		return company;
	}
	public void setCompany(String company) {
		this.company = company;
	}
	
	
}
