
import javax.servlet.*;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class contact1
 */
@WebServlet("/contact1")
public class contact1 extends HttpServlet {
	@Override
	public void service(HttpServletRequest req,HttpServletResponse res) throws ServletException, IOException
	{
		PrintWriter pw=res.getWriter();
		res.setContentType("text/html");
		
		try
		{
			Class.forName("oracle.jdbc.driver.OracleDriver");
			Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","system","1234");
				Statement st1=con.createStatement();
				ResultSet rs=st1.executeQuery("select * from contact");                     
	            pw.println("<html><head><link rel=\"stylesheet\" href=\"bootstrap.min.css\"/></head><body><h2 align=center text-decoration=underline>Contact Details</h2>");
	            pw.println("<hr></br>");
	            pw.println("<form style=\"margin-left:700px;\r\n"
	            		+ "       margin-right:900px;\r\n"
	            		+ "        border-width:1px;\r\n"
	            		+ "        margin-top:50px;\">");
	            pw.println("<table cellspacing='0' cellpadding='5' border='1' align=center class=\"table table-striped table-hover\">");
	            pw.println("<tr>");
	            
	            pw.println("<td><b>Name</b></td>");
	            pw.println("<td><b>Email</b></td>");
	            pw.println("<td><b>Subject</b></td>");
	            pw.println("<td><b>Message</b></td>");
	            pw.println("</tr>");
	            while(rs.next()) 
	            {
	            
	    		String a=rs.getString("name");
	    		String b=rs.getString("email");
	    		String c=rs.getString("subject");
	    		String d=rs.getString("message");
	             pw.println("<tr>");
	             pw.println("<td>"+a + "</td>");
	             pw.println("<td>"+b + "</td>");
	             pw.println("<td>"+c + "</td>");
	             pw.println("<td>"+d + "</td>");
	             pw.println("</tr>");
	            }
	            pw.println("</table></form></br><hr></body></html>");
	           
		}
		catch(Exception ae)
		{
			pw.println("the error is "+ae);
		}
	}			
}
