import javax.servlet.*;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class editb
 */
@WebServlet("/editb")
public class editb extends HttpServlet {
	
	@Override
	public void service(HttpServletRequest req,HttpServletResponse res) throws ServletException, IOException
	{
		PrintWriter pw=res.getWriter();
		res.setContentType("text/html");
		String a=req.getParameter("id");
		String b=req.getParameter("name");
		String c=req.getParameter("email");
		String d=req.getParameter("mobile");
		String e=req.getParameter("date1");
		String f=req.getParameter("time1");
		String g=req.getParameter("guest");
		try
		{
			Class.forName("oracle.jdbc.driver.OracleDriver");
			Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","system","1234");
			PreparedStatement ps=con.prepareStatement("update burgur set name=?,email=?,mobile=?,date1=?,time1=?,guest=? where id=?");
			ps.setString(1,b);
			ps.setString(2,c);
			ps.setString(3,d);
			ps.setString(4,e);
			ps.setString(5,f);
			ps.setInt(6,Integer.parseInt(g));
			ps.setInt(7,Integer.parseInt(a));
			ps.execute();
			Statement st1=con.createStatement();
			ResultSet rs=st1.executeQuery("select * from burgur");                     
	        pw.println("<html><body bgcolor=powderblue><h2 align=center text-decoration=underline>Book Table Details</h2>");
	        pw.println("<hr></br><table cellspacing='0' cellpadding='5' border='1' align=center>");
	        pw.println("<tr>");
	        pw.println("<td><b>ID</b></td>");
	        pw.println("<td><b>Name</b></td>");
	        pw.println("<td><b>Email</b></td>");
	        pw.println("<td><b>Mobile number</b></td>");
	        pw.println("<td><b>Date</b></td>");
	        pw.println("<td><b>Time</b></td>");
	        pw.println("<td><b>guest</b></td>");
	        pw.println("<td><b>Edit</b></td>");
	        pw.println("<td><b>Delete</b></td>");
	        pw.println("</tr>");
	        while(rs.next()) 
	        {
	         pw.println("<tr>");
	         pw.println("<td>"+rs.getString(1) + "</td>");
	         pw.println("<td>"+rs.getString(2) + "</td>");
	         pw.println("<td>"+rs.getString(3) + "</td>");
	         pw.println("<td>"+rs.getString(4) + "</td>");
	         pw.println("<td>"+rs.getString(5) + "</td>");
	         pw.println("<td>"+rs.getString(6) + "</td>");  
	         pw.println("<td>"+rs.getString(7) + "</td>"); 
	         pw.println("<td>"+"<a href='edit.html?id='"+ ">Edit</a>"+"</td>");
	         pw.println("<td>"+"<a href='delete.html?id='"+ ">Delete</a>"+"</td>");
	         pw.println("</tr>");
	        }
	        pw.println("</table></br><hr></body></html>");
		}
		catch(Exception ae)
		{
			pw.println("the error is "+ae);
		}
	}
}
