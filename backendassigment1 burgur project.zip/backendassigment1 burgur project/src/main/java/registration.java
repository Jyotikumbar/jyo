import javax.servlet.*;
import java.io.*;
import java.sql.*;
import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/registration")
public class registration extends HttpServlet {
	@Override
public void service(ServletRequest req, ServletResponse res) throws ServletException, IOException
{
	PrintWriter pw=res.getWriter();
	res.setContentType("text/html");
	String a=req.getParameter("t1");
	String b=req.getParameter("t2");
	String c=req.getParameter("t3");
	String d=req.getParameter("t4");
	
	
	try
	{
	Class.forName("oracle.jdbc.driver.OracleDriver");
	Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","system","1234");
		 PreparedStatement ps=con.prepareStatement("insert into employee201 values(?,?,?,?)");
		ps.setInt(1,Integer.parseInt(a));
		ps.setString(2,b);
		ps.setInt(3,Integer.parseInt(c));
		ps.setInt(4,Integer.parseInt(d));
		ps.execute();
		pw.print("row inserted");
	Statement st1=con.createStatement();
		ResultSet rs=st1.executeQuery("select * from employee201 order by empid");               
        
        pw.println("<html><body><h2>The Select query has following results : </h2>");
        pw.println("<hr></br><table cellspacing='0' cellpadding='5' border='1'>");
        pw.println("<tr>");
        pw.println("<td><b>Employee ID</b></td>");
        
        pw.println("<td><b>Employee Name</b></td>");
        pw.println("<td><b>Employee Salary</b></td>");
        pw.println("<td><b>Employee Designation</b></td>");
        pw.println("</tr>");
        while(rs.next()) 
        {
         pw.println("<tr>");
         pw.println("<td>"+rs.getString(1) + "</td>");
         pw.println("<td>"+rs.getString(2) + "</td>");
         pw.println("<td>"+rs.getString(3) + "</td>");
         pw.println("<td>"+rs.getString(4) + "</td>");
         
         pw.println("</tr>");
        }
        pw.println("</table></br><hr></body></html>");
			 
		
	}		
	
	catch(Exception ae)
	{
		ae.printStackTrace();
	}	

}
}
