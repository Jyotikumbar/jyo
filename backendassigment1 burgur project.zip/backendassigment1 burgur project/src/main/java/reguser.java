import javax.servlet.*;
import java.io.*;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class reguser
 */
@WebServlet("/reguser")
public class reguser extends HttpServlet {
	@Override
	public void service(HttpServletRequest req,HttpServletResponse res) throws ServletException, IOException
	{
		PrintWriter pw=res.getWriter();
		res.setContentType("text/html");
		String a=req.getParameter("username");
		String b=req.getParameter("email");
		String c=req.getParameter("password");
		try
		{
			Class.forName("oracle.jdbc.driver.OracleDriver");
			Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","system","1234");
			PreparedStatement ps=con.prepareStatement("insert into reg values(?,?,?)");
			ps.setString(1,a);
				ps.setString(2,b);
				ps.setString(3,c);
				ps.execute();
				res.sendRedirect("Login.html");
         }
		catch(Exception ae)
		{
			pw.println("the error is "+ae);
		}
	}
}
