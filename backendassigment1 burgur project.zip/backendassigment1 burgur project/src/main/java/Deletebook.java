

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class deletebook
 */
@WebServlet("/deletebook")
public class Deletebook extends HttpServlet {
	@Override
	public void service(HttpServletRequest req,HttpServletResponse res) throws ServletException, IOException
	{
	PrintWriter pw=res.getWriter();
	res.setContentType("text/html");
	String a=req.getParameter("name");
	/*String b=req.getParameter("name");
	String c=req.getParameter("email");
	String d=req.getParameter("password");
	String e=req.getParameter("mobile");*/
	try
	{
		Class.forName("oracle.jdbc.driver.OracleDriver");
		Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","system","1234");
		PreparedStatement ps=con.prepareStatement("delete burgur where name=?");
		ps.setString(1,a);
		ps.execute();
	}
	catch(Exception ae)
	{
		pw.println("the error is "+ae);
	}

}
}
