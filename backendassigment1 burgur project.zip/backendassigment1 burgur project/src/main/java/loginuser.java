import javax.servlet.*;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class loginuser
 */
@WebServlet("/loginuser")
public class loginuser extends HttpServlet {
	@Override
	public void service(HttpServletRequest req,HttpServletResponse res) throws ServletException, IOException
	{
		PrintWriter pw=res.getWriter();
		res.setContentType("text/html");
		String user=req.getParameter("t1");
		String pass=req.getParameter("t2");
				try
		{
		Class.forName("oracle.jdbc.driver.OracleDriver");
		Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","system","1234");
		 PreparedStatement ps=con.prepareStatement("select * from reg where username=? and password=?");
			ps.setString(1,user);
			ps.setString(2,pass);
			ResultSet rs=ps.executeQuery();
			int x=0;
			while(rs.next())
			{
				x=1;//when there is data
			}
			if(x==1)
			{
				res.sendRedirect("index.html");
			}
			else
			{
				res.sendRedirect("Login.html");
			}
	}	
		catch(Exception ae)
		{
			ae.printStackTrace();
		}
}
}
