import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import java.util.*;

import org.hibernate.*;
import org.hibernate.cfg.*;
public class Emp {
	
	public static void main(String args[])throws Exception
	{ 
		String id,name,phone,address;
		Scanner sc=new Scanner(System.in);		 
		 //System.out.println("Enter Employee details");
		Configuration cfg=new Configuration();
		SessionFactory sf=cfg.configure().buildSessionFactory();
		 cfg.configure("hibernate.cfg.xml"); 
		Session ss=sf.openSession();
		mypojo emp=new mypojo();
		
		 System.out.println("enter 1-for insert 2-for update 3-for delete 4-view");
		 int n=sc.nextInt();
		switch(n)
		{
		case 1: Transaction tx=ss.beginTransaction();
			System.out.println("insert data");
        //Add new Employee object
        System.out.println("Enter Employee details");
   	     System.out.println("Enter Employee id");
   	       id=sc.next();
   	     System.out.println("Enter Employee name");
   	      name=sc.next();
   	     System.out.println("Enter Employee phoneno");
   	      phone=sc.next();
   	       System.out.println("Enter Employee address");
   	     address=sc.next();	 
        emp.setId(id);
        emp.setName(name);
        emp.setPhone(phone);
        emp.setAddress(address);
         
        //Save the employee in database
        ss.save(emp);
     System.out.println("data save sucessfully");
        //Commit the transaction
        //session.getTransaction().commit();
        //HibernateUtil.shutdown();
         tx.commit();
	   break;
		case 2: Transaction tx2=ss.beginTransaction();
		        System.out.println("update the data");
		        System.out.println("enter the id u want to update");
		         id=sc.next();
		         System.out.println("Enter Employee details");
		   	     System.out.println("Enter Employee name");
		   	      name=sc.next();
		   	     System.out.println("Enter Employee phoneno");
		   	      phone=sc.next();
		   	       System.out.println("Enter Employee address");
		   	     address=sc.next();	       
			    Query q2=ss.createQuery("update mypojo set name=:n,phone=:p,address=:a where id=:i");
			    q2.setParameter("n",name);
			    q2.setParameter("p",phone);
			    q2.setParameter("a",address);
			    q2.setParameter("i",id);
			    int status=q2.executeUpdate();
			    System.out.println(status+"the row updated");
			    tx2.commit();
		       break;
		case 3:Transaction tx3=ss.beginTransaction();
		      System.out.println("delete the data");
		        System.out.println("enter the id u want to update");
                id=sc.next();
		      Query q3=ss.createQuery("delete from mypojo where id=:p");
		      q3.setParameter("p", id);
		      int status1=q3.executeUpdate();
			    System.out.println(status1+"the row deleted");
			    tx3.commit();
		       break;
		case 4:Transaction tx4=ss.beginTransaction();
			   System.out.println("view the data");
			    Query q5 = ss.createQuery("from mypojo");
				q5.setFirstResult(0);
				q5.setMaxResults(10);
				List stud1 = q5.list();
				System.out.println(stud1);
				Iterator it1 = stud1.iterator();
				while (it1.hasNext()) {
					emp = (mypojo) it1.next();
					System.out.println("Display");
					System.out.println(emp.getId());
					System.out.println(emp.getName());
					System.out.println(emp.getPhone());
					System.out.println(emp.getAddress());
				}
		            break;
		default :System.out.println("invalid choice");
		          break;
		}
	}	
}
